module FPM
  VERSION = "1.9.3"
end
