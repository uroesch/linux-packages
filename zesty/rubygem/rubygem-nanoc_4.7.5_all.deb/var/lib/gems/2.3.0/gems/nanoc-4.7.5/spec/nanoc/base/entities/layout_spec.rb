describe Nanoc::Int::Layout do
  it_behaves_like 'a document'
end
