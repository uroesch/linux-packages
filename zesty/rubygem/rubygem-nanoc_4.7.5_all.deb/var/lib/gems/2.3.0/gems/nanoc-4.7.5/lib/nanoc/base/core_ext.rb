require 'nanoc/base/core_ext/array'
require 'nanoc/base/core_ext/hash'
require 'nanoc/base/core_ext/pathname'
require 'nanoc/base/core_ext/string'
