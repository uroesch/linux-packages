# @api private
module Nanoc::DataSources
end

require_relative 'data_sources/filesystem'
