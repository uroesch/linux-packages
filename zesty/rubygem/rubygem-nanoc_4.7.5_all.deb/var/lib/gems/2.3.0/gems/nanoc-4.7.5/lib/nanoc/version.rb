module Nanoc
  # The current Nanoc version.
  VERSION = '4.7.5'.freeze
end
