require 'helper'

class Nanoc::CLI::LoggerTest < Nanoc::TestCase
  def test_stub; end
end
