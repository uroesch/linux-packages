module Nanoc
  class LayoutView < ::Nanoc::View
    include Nanoc::DocumentViewMixin
  end
end
