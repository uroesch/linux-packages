describe Nanoc::Int::Item do
  it_behaves_like 'a document'
end
