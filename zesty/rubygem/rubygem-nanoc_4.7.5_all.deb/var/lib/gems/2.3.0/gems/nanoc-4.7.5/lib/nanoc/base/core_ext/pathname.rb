# @api private
module Nanoc::PathnameExtensions
end

# @api private
class Pathname
  include Nanoc::PathnameExtensions
end
