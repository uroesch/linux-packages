require "schash/schema"
require "schash/validator"
require "schash/version"

module Schash
  # Your code goes here...
end
