module Schash
  module Schema
    module Rule
      class Base
        def optional?
          false # default
        end
      end
    end
  end
end

