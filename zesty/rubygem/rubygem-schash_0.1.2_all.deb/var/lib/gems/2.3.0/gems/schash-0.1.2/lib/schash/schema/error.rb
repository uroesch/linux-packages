module Schash
  module Schema
    class Error < Struct.new(:position, :message); end
  end
end

