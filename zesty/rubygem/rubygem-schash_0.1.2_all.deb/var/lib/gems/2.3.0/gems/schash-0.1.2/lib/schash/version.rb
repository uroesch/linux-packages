module Schash
  VERSION = "0.1.2"
end
