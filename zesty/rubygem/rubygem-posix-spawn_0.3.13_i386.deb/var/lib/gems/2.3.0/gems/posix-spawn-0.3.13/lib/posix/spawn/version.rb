module POSIX
  module Spawn
    VERSION = '0.3.13'
  end
end
