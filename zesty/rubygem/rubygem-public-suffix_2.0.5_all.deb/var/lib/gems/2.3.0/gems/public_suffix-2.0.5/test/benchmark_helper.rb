require "benchmark"

$LOAD_PATH.unshift File.expand_path("../../lib", __FILE__)
require "public_suffix"
