# :stopdoc:
# This dummy class is to keep RDoc and YARD from complaining about an empty
# lib directory.
module SQLite3
  class Dummy
  end
end
# :startdoc:
