Special-built applications for use in tests that will hopefully reveal
various features and edge cases
