module GLI
  unless const_defined? :VERSION
    VERSION = '2.16.0'
  end
end
