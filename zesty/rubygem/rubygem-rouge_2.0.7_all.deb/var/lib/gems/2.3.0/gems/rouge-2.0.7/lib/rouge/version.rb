# -*- coding: utf-8 -*- #

module Rouge
  def self.version
    "2.0.7"
  end
end
