require 'stringex/configuration/base'
require 'stringex/configuration/configurator'
require 'stringex/configuration/string_extensions'
