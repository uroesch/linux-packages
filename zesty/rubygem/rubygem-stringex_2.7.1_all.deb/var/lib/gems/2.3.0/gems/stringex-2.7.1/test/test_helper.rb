require 'test/unit'
$: << File.join(File.expand_path(File.dirname(__FILE__)), '../lib')
