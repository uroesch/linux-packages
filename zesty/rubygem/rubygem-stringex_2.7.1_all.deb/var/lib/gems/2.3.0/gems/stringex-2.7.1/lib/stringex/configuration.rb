require "stringex/configuration/base"
require "stringex/configuration/configurator"
require "stringex/configuration/acts_as_url"
require "stringex/configuration/string_extensions"
