require 'hashery'

include Hashery
