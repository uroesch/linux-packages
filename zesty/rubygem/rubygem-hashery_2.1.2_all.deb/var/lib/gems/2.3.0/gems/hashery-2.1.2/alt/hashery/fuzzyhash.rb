require 'hashery/fuzzy_hash'
