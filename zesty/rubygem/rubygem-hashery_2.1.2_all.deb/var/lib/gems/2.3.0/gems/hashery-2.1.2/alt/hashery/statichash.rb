require 'hashery/static_hash'
