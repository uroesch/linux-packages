require 'hashery/query_hash'
