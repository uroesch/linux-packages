require 'hashery/linked_list'
