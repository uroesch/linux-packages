require 'lemon'
require 'ae'
require 'ae/legacy' # bacause imitation BasicObject sucks
require 'ae/pry'

require 'hashery'

include Hashery
