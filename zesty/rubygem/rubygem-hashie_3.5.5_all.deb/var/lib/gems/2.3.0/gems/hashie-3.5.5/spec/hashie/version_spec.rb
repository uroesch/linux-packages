require 'spec_helper'

describe Hashie do
  it 'has a version' do
    expect(Hashie::VERSION).not_to be_nil
  end
end
