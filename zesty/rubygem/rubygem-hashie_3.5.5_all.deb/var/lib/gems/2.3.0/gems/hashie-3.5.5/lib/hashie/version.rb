module Hashie
  VERSION = '3.5.5'
end
