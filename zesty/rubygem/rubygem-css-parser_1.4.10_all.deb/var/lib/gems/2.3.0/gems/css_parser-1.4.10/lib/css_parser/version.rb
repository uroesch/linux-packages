module CssParser
  VERSION = "1.4.10".freeze
end
