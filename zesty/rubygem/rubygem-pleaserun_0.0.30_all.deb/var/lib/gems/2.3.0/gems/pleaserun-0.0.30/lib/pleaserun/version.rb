module PleaseRun
  VERSION = "0.0.30"
end
