module UNF
  class Normalizer
    VERSION = "0.0.7.2"
  end
end
