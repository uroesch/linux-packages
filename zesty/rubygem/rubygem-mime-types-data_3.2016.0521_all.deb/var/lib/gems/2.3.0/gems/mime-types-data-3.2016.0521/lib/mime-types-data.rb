# frozen_string_literal: true

require 'mime/types/data'
