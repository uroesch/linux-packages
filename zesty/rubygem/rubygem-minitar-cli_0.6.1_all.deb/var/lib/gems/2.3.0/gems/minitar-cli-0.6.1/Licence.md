## Licence

minitar-cli is free software that may be redistributed and/or modified under
the terms of Ruby’s licence or the Simplified BSD licence.

* Copyright 2004–2017 Austin Ziegler.
* Portions copyright 2004 Mauricio Julio Fernández Pradier.

### Simplified BSD Licence

See the file docs/bsdl.txt in the main distribution.

### Ruby’s Licence

See the file docs/ruby.txt in the main distribution.
