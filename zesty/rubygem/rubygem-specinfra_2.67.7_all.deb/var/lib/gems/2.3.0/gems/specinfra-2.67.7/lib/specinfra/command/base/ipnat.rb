class Specinfra::Command::Base::Ipnat < Specinfra::Command::Base
end
