class Specinfra::Command::Linuxmint; end
