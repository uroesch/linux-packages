class Specinfra::Command::Amazon;end

