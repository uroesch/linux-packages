class Specinfra::Command::Linux::Base::Ppa < Specinfra::Command::Base::Ppa
end
