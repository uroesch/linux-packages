class Specinfra::Command::Sles::Base < Specinfra::Command::Suse::Base
end
