class Specinfra::Command::Suse::Base < Specinfra::Command::Linux::Base
end
