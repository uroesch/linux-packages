class Specinfra::Command::Openbsd; end
