class Specinfra::Command::Linux::Base::Package < Specinfra::Command::Base::Package
end
