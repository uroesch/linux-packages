class Specinfra::Command::Openbsd::Base < Specinfra::Command::Base
end


