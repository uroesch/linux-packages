class Specinfra::Command::Plamo::Base < Specinfra::Command::Linux::Base
end

