class Specinfra::Command::Cumuluslinux; end
class Specinfra::Command::Cumulusnetworks; end










