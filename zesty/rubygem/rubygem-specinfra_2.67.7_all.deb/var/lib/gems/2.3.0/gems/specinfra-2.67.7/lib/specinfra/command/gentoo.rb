class Specinfra::Command::Gentoo; end
