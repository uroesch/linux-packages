class Specinfra::Command::Freebsd::V9::Package < Specinfra::Command::Freebsd::V8::Package 
end
