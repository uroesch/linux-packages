class Specinfra::Command::Freebsd::V9 < Specinfra::Command::Freebsd::Base
end
