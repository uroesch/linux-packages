class Specinfra::Command::Linux; end
