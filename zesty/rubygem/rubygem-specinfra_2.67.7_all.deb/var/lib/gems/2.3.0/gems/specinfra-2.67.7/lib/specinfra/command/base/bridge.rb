class Specinfra::Command::Base::Bridge < Specinfra::Command::Base
end
