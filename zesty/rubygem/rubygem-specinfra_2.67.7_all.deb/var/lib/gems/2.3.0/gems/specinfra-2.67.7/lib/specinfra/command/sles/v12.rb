class Specinfra::Command::Sles::V12 < Specinfra::Command::Sles::Base
end

