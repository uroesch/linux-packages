class Specinfra::Command::Alpine; end
