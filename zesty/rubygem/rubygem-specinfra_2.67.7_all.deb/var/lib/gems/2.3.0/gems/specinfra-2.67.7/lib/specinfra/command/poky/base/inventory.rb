class Specinfra::Command::Poky::Base::Inventory < Specinfra::Command::Linux::Base::Inventory
end
