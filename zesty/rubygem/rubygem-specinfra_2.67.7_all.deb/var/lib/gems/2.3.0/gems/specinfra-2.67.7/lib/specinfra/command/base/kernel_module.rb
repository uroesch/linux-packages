class Specinfra::Command::Base::KernelModule < Specinfra::Command::Base
end
