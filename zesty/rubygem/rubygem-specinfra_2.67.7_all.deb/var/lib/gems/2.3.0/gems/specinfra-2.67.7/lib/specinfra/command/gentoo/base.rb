class Specinfra::Command::Gentoo::Base < Specinfra::Command::Linux::Base
end
