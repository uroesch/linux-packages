class Specinfra::Command::Base::Iptables < Specinfra::Command::Base
end
