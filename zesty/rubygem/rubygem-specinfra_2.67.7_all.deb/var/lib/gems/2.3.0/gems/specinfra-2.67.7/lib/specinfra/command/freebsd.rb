class Specinfra::Command::Freebsd; end
