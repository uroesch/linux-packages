class Specinfra::Command::Poky::Base::Interface < Specinfra::Command::Linux::Base::Interface
end
