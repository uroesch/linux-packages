class Specinfra::Command::Windows; end
