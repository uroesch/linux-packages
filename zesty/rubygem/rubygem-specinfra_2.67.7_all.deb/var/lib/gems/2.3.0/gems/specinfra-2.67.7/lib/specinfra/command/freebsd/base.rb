class Specinfra::Command::Freebsd::Base < Specinfra::Command::Base
end

