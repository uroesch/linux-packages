class Specinfra::Command::Opensuse; end
