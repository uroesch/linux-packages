class Specinfra::Command::Linux::Base < Specinfra::Command::Base
end
