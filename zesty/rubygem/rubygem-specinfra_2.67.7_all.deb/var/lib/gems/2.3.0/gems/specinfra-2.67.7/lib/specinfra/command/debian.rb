class Specinfra::Command::Debian; end
