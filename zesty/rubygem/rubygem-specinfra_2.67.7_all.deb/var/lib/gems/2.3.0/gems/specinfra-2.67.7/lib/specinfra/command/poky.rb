class Specinfra::Command::Poky; end
