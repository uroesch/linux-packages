class Specinfra::Command::Ubuntu; end










