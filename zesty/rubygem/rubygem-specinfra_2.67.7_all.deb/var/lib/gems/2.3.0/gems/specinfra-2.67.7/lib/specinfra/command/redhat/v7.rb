class Specinfra::Command::Redhat::V7 < Specinfra::Command::Redhat::Base
end

