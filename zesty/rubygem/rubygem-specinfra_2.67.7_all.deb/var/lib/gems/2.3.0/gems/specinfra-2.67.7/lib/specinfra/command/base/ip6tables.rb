class Specinfra::Command::Base::Ip6tables < Specinfra::Command::Base
end
