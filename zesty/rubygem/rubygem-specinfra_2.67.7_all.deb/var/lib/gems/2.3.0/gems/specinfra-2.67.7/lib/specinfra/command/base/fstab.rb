class Specinfra::Command::Base::Fstab < Specinfra::Command::Base
end
