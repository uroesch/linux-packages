class Specinfra::Command::Ubuntu::V15 < Specinfra::Command::Ubuntu::Base; end
