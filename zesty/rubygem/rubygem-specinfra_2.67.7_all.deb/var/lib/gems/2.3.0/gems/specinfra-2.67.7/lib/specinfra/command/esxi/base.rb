class Specinfra::Command::Esxi::Base < Specinfra::Command::Linux::Base
end
