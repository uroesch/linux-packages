class Specinfra::Command::Arch; end
