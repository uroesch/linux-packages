class Specinfra::Command::Fedora::Base < Specinfra::Command::Redhat::Base
end
