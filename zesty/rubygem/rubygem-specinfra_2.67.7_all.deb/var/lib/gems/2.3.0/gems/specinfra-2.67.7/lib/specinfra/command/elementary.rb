class Specinfra::Command::Elementary; end
