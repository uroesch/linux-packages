class Specinfra::Command::Freebsd::V7 < Specinfra::Command::Freebsd::Base
end
