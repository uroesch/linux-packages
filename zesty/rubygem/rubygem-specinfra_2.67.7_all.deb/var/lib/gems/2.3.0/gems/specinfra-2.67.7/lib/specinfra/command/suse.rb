class Specinfra::Command::Suse; end
