class Specinfra::Command::Arch::Base < Specinfra::Command::Linux::Base
end









