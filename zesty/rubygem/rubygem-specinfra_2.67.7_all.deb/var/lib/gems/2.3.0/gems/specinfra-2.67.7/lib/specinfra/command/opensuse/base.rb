class Specinfra::Command::Opensuse::Base < Specinfra::Command::Suse::Base
end

