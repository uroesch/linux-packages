class Specinfra::Command::Smartos::Base < Specinfra::Command::Solaris::Base
end

