class Specinfra::Command::Redhat;end
