class Specinfra::Command::Debian::Base < Specinfra::Command::Linux::Base
end









