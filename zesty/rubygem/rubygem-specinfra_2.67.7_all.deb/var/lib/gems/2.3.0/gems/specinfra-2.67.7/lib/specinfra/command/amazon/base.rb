class Specinfra::Command::Amazon::Base < Specinfra::Command::Redhat::Base
end
