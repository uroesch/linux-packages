class Specinfra::Command::Aix; end
