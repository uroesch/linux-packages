class Specinfra::Command::Smartos; end
