class Specinfra::Command::Redhat::Base::Service < Specinfra::Command::Linux::Base::Service
end
