class Specinfra::Command::Solaris; end
