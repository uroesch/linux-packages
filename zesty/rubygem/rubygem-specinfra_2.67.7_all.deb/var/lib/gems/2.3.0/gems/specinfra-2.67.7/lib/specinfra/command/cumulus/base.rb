class Specinfra::Command::Cumuluslinux::Base < Specinfra::Command::Debian::Base
end

class Specinfra::Command::Cumulusnetworks::Base < Specinfra::Command::Cumuluslinux::Base
end

