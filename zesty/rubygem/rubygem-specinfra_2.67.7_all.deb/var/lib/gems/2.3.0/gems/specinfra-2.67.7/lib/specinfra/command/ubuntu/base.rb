class Specinfra::Command::Ubuntu::Base < Specinfra::Command::Debian::Base
end
