class Specinfra::Command::Darwin::Base < Specinfra::Command::Base
end
