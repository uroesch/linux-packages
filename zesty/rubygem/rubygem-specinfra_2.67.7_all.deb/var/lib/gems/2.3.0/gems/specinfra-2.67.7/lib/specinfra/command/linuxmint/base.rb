class Specinfra::Command::Linuxmint::Base < Specinfra::Command::Ubuntu::Base
end
