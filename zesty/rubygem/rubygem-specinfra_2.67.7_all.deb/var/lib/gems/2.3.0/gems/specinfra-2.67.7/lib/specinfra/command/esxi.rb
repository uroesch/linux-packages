class Specinfra::Command::Esxi; end
