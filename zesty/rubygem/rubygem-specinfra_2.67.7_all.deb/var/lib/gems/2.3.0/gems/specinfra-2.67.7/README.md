# Specinfra

TODO: Write a gem description

## Installation

Add this line to your application's Gemfile:

    gem 'specinfra'

And then execute:

  ```
  bundle
  ```

Or install it yourself as:

  ```
  gem install specinfra
  ```

## Running tests

  ```
  bundle exec rake
  ```
  
## Usage

TODO: Write usage instructions here

----

## Maintenance policy of Serverspec/Specinfra

* The person who found a bug should fix the bug by themself.
* If you find a bug and cannot fix it by yourself, send a pull request and attach test code to reproduce the bug, please.
* The person who want a new feature should implement it by themself.
* For above reasons, I accept pull requests only and disable issues.
* If you'd like to discuss about a new feature before implement it, make an empty commit and send [a WIP pull request](http://ben.straub.cc/2015/04/02/wip-pull-request/). But It is better that the WIP PR has some code than an empty commit.

## Contributing

1. Fork it
2. Create your feature branch (`git checkout -b my-new-feature`)
3. Commit your changes (`git commit -am 'Add some feature'`)
4. Push to the branch (`git push origin my-new-feature`)
5. Create new Pull Request
