class Specinfra::Command::Nixos::Base < Specinfra::Command::Linux::Base
end
