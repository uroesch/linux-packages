class Specinfra::Command::Redhat::Base::Port < Specinfra::Command::Base::Port
end
