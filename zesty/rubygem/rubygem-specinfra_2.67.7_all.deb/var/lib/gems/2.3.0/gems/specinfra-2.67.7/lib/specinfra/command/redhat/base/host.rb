class Specinfra::Command::Redhat::Base::Host < Specinfra::Command::Base::Host
end
