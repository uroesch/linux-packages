class Specinfra::Command::Openbsd::V57 < Specinfra::Command::Openbsd::Base
end
