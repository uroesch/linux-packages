class Specinfra::Command::Linux::Base::Yumrepo < Specinfra::Command::Base::Yumrepo
end
