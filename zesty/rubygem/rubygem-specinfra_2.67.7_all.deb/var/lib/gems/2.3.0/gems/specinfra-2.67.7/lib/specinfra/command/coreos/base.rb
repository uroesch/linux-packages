class Specinfra::Command::Coreos::Base < Specinfra::Command::Linux::Base
end
