class Specinfra::Command::Base::Ppa < Specinfra::Command::Base
end
