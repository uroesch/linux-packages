class Specinfra::Command::Base::Yumrepo < Specinfra::Command::Base
end

