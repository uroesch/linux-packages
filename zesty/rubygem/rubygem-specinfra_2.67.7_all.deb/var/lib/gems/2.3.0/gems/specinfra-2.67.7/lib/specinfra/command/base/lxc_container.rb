class Specinfra::Command::Base::LxcContainer < Specinfra::Command::Base
end
