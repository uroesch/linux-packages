class Specinfra::Command::Debian::Base::Port < Specinfra::Command::Linux::Base::Port
end
