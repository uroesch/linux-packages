class Specinfra::Command::Linux::Base::Service < Specinfra::Command::Base::Service
end
