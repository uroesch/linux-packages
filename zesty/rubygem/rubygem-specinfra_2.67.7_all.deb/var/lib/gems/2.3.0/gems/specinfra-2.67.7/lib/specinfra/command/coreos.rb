class Specinfra::Command::Coreos; end
