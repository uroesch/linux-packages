class Specinfra::Command::Freebsd::V7::Package <  Specinfra::Command::Freebsd::V6::Package
end
