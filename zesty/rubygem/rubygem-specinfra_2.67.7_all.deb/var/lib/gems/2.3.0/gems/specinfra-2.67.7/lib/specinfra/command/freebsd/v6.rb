class Specinfra::Command::Freebsd::V6 < Specinfra::Command::Freebsd::Base
end
