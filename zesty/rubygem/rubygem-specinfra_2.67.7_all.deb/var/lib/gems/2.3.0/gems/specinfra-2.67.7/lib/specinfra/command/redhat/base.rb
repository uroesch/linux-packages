class Specinfra::Command::Redhat::Base < Specinfra::Command::Linux::Base
end
