class Specinfra::Command::Raspbian < Specinfra::Command::Debian; end
