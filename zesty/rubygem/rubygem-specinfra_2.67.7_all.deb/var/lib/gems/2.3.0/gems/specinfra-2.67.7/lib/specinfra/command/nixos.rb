class Specinfra::Command::Nixos; end
