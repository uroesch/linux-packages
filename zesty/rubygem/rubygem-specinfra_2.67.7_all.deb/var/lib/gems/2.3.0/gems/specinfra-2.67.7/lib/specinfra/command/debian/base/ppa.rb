class Specinfra::Command::Debian::Base::Ppa < Specinfra::Command::Linux::Base::Ppa
end
