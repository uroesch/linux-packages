class Specinfra::Command::Fedora::V15 < Specinfra::Command::Fedora::Base
end
