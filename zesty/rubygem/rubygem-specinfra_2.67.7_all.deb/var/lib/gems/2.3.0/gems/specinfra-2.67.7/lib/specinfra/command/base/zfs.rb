class Specinfra::Command::Base::Zfs < Specinfra::Command::Base; end
