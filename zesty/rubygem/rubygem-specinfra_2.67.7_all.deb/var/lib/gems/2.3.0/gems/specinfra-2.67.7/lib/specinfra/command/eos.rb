class Specinfra::Command::Eos; end
