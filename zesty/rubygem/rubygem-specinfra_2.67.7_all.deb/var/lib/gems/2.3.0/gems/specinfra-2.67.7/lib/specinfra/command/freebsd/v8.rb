class Specinfra::Command::Freebsd::V8 < Specinfra::Command::Freebsd::Base
end
