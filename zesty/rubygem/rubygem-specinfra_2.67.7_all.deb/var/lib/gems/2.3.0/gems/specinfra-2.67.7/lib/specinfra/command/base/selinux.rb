class Specinfra::Command::Base::Selinux < Specinfra::Command::Base
end
