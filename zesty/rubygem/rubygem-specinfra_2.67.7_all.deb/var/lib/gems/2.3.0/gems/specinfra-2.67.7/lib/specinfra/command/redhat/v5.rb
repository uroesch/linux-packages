class Specinfra::Command::Redhat::V5 < Specinfra::Command::Redhat::Base
end

