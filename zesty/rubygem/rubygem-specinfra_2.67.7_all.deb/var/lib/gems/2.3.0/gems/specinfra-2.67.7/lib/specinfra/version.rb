module Specinfra
  VERSION = "2.67.7"
end
