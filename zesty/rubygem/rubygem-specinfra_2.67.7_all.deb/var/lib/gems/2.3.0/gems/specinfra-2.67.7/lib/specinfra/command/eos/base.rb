class Specinfra::Command::Eos::Base < Specinfra::Command::Fedora::Base
end
