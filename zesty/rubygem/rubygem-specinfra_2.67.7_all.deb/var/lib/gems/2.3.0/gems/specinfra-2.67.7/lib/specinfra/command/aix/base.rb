class Specinfra::Command::Aix::Base < Specinfra::Command::Base
end
