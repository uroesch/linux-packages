class Specinfra::Command::Debian::V8 < Specinfra::Command::Debian::Base
end
