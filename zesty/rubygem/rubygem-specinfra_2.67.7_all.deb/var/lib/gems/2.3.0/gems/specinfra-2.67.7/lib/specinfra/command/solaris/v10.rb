class Specinfra::Command::Solaris::V10 < Specinfra::Command::Solaris::Base
end
