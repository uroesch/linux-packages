class Specinfra::Command::Darwin; end
