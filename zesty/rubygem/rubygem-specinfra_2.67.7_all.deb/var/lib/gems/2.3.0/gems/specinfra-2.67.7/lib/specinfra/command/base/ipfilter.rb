class Specinfra::Command::Base::Ipfilter < Specinfra::Command::Base
end
