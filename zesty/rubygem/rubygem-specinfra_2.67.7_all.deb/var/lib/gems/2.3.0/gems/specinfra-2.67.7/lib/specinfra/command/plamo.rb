class Specinfra::Command::Plamo; end
