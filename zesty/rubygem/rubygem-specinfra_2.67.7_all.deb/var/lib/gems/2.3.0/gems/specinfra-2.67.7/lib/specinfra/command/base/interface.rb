class Specinfra::Command::Base::Interface < Specinfra::Command::Base
end
