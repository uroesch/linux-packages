class Specinfra::Command::Alpine::Base < Specinfra::Command::Linux::Base
end
