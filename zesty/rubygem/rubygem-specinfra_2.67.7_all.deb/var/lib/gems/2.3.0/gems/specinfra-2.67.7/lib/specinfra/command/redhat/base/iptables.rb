class Specinfra::Command::Redhat::Base::Iptables < Specinfra::Command::Linux::Base::Iptables
end









