class Specinfra::Command::Base::Bond < Specinfra::Command::Base
end
