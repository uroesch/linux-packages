class Specinfra::Command::Elementary::Base < Specinfra::Command::Ubuntu::Base
end
