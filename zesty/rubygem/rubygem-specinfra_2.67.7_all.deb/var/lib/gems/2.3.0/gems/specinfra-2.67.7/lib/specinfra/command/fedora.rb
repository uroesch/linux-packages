class Specinfra::Command::Fedora; end
