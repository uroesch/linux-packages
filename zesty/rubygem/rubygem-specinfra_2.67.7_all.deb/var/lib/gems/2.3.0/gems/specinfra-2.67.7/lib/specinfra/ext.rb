require 'specinfra/ext/class'
require 'specinfra/ext/string'
