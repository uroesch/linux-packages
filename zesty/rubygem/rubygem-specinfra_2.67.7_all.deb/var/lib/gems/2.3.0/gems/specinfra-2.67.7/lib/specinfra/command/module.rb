module Specinfra
  module Command
    module Module
    end
  end
end

