class Specinfra::Command::Solaris::Base < Specinfra::Command::Base
end
