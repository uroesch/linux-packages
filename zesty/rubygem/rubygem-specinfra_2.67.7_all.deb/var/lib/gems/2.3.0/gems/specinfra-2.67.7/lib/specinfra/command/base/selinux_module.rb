class Specinfra::Command::Base::SelinuxModule < Specinfra::Command::Base
end
