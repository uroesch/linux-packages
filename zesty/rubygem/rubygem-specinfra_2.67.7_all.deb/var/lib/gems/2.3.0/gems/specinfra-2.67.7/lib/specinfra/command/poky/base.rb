class Specinfra::Command::Poky::Base < Specinfra::Command::Linux::Base
end
