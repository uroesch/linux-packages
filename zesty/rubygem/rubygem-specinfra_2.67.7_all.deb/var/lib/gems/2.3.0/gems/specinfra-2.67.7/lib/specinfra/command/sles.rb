class Specinfra::Command::Sles; end
