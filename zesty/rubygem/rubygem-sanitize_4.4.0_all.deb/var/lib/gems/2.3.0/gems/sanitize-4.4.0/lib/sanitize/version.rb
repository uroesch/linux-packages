# encoding: utf-8

class Sanitize
  VERSION = '4.4.0'
end
