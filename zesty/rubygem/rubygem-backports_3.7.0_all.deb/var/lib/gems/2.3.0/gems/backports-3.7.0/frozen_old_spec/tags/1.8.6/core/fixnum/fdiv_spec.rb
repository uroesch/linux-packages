fails:Fixnum#fdiv follows the coercion protocol
