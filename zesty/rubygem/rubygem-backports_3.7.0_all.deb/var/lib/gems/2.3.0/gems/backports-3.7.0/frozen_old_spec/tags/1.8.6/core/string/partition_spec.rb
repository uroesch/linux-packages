fails:String#partition with String sets global vars if regexp used
