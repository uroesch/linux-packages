fails:Hash#select returns a Hash of entries for which block is true
