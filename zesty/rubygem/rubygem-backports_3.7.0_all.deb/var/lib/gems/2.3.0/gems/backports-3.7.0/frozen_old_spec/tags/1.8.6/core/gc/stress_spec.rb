fails:GC.stress returns current status of GC stress mode
fails:GC.stress= sets the stress mode
