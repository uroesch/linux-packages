require 'backports/1.8.7/io/each_char'
