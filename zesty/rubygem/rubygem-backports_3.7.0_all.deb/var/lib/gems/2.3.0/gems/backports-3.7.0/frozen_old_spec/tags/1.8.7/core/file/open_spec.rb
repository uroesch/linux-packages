fails:File.open on a FIFO opens it as a normal file
fails:File.open raises a SystemCallError if passed an invalid Integer type
fails:File.open defaults external_encoding to ASCII-8BIT for binary modes
fails:File.open when passed a file descriptor opens a file
fails:File.open when passed a file descriptor opens a file when passed a block
