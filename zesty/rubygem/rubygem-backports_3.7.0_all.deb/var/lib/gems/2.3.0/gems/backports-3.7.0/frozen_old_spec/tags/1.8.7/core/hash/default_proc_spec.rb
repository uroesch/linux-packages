fails:Hash#default_proc= raises an error if passed nil
fails:Hash#default_proc= raises a TypeError if passed a lambda with an arity other than 2
fails:Hash#default_proc= raises a RuntimeError if self is frozen
