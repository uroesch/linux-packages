fails:Symbol#to_proc raises an ArgumentError when calling #call on the Proc without receiver
