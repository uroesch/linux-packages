fails:Math.log2 raises an Errno::EDOM if the argument is less than 0
fails:Math.log2 raises an TypeError if the argument cannot be coerced with Float()
fails:Math.log2 raises an TypeError if passed a numerical argument as a string
fails:Math.log2 returns NaN given NaN
fails:Math.log2 raises a TypeError if the argument cannot be coerced with Float()
fails:Math.log2 raises a TypeError if passed a numerical argument as a string
