require 'backports/1.8.7/enumerable/inject'
