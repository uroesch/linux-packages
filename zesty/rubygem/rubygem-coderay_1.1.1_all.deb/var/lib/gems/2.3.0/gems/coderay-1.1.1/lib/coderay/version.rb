module CodeRay
  VERSION = '1.1.1'
end
