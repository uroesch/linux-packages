class Mechanize::Form::Hidden < Mechanize::Form::Field
end

