##
# An Image holds downloaded data for an image/* response.

class Mechanize::Image < Mechanize::Download
end

