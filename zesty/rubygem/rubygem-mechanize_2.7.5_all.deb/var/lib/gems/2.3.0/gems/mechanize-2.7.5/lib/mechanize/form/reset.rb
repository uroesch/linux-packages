class Mechanize::Form::Reset < Mechanize::Form::Button
end

