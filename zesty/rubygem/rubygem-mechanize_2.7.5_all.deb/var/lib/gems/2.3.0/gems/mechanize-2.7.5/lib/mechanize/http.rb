##
# Mechanize::HTTP contains classes for communicated with HTTP servers.  All
# API under this namespace is considered private and is subject to change at
# any time.

class Mechanize::HTTP
end

