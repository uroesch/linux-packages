require 'mechanize/test_case'

class TestMechanizeImage < Mechanize::TestCase

  # empty subclass, no tests

end

