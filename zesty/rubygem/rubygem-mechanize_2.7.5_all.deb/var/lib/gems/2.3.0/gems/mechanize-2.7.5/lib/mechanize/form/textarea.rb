class Mechanize::Form::Textarea < Mechanize::Form::Field
end

