class Mechanize::Form::Text < Mechanize::Form::Field
end

