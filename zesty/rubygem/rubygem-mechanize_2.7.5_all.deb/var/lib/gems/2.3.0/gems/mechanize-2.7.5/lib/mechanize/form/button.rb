##
# A Submit button in a Form

class Mechanize::Form::Button < Mechanize::Form::Field
end

