class Mechanize::Form::Submit < Mechanize::Form::Button
end

