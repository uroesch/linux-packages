class Mechanize
  VERSION = "2.7.5"
end
