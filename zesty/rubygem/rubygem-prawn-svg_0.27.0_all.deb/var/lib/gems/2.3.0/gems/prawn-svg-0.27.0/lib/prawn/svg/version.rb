module Prawn
  module SVG
    VERSION = '0.27.0'
  end
end
