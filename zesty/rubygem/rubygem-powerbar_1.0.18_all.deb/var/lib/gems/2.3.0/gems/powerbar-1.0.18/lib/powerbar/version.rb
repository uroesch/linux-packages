class Powerbar
  VERSION = "1.0.18"
end
