module GritExt
  extend self

  def version
    "0.8.1"
  end
end
