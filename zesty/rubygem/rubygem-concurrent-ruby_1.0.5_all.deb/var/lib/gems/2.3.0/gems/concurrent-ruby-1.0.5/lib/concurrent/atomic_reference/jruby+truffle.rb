require 'atomic'
require 'concurrent/atomic_reference/rbx'
