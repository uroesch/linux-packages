class Mustache
  VERSION = '1.0.5'
end
