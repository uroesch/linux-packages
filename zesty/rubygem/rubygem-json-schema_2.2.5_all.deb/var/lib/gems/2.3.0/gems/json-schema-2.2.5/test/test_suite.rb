require 'test/unit'
require File.dirname(__FILE__) + '/../lib/json-schema'

class SuiteTest < Test::Unit::TestCase
  def test_draft_4
  	print "\n\nDRAFT-04 SUITE TESTS\n"
  	print     "--------------------\n"
  	tests = 0
  	passes = 0
  	Dir.glob(File.dirname(__FILE__) + "/suite/tests/draft4/*.json").each do |file_path|
  		data = JSON.parse(File.read(file_path))
  		data.each do |test_desc|
  			puts "Suite Test: #{test_desc["description"]}"
  			test_desc["tests"].each do |test|
  				tests = tests + 1
  				print " - #{test["description"]}: "
  				begin
						if JSON::Validator.validate(test_desc["schema"], test["data"], :version => :draft4) == test["valid"]
							puts green("pass")
							passes = passes + 1
			  		else
			  			puts "#{red("fail")} - expected #{test["valid"]}, got #{JSON::Validator.validate(test_desc["schema"], test["data"], :version => :draft4)}"
			  		end
			  	rescue
			  			puts "#{red("fail")} - exception thrown"
			  	end
	  		end
  		end
  	end
  end

  def test_draft_3
  	print "\n\nDRAFT-03 SUITE TESTS\n"
  	print     "--------------------\n"

  	tests = 0
  	passes = 0
  	Dir.glob(File.dirname(__FILE__) + "/suite/tests/draft3/*.json").each do |file_path|
  		data = JSON.parse(File.read(file_path))
  		data.each do |test_desc|
  			puts "Suite Test: #{test_desc["description"]}"
  			test_desc["tests"].each do |test|
  				tests = tests + 1
  				print " - #{test["description"]}: "
  				begin
						if JSON::Validator.validate(test_desc["schema"], test["data"], :version => :draft3) == test["valid"]
							puts green("pass")
							passes = passes + 1
			  		else
			  			puts "#{red("fail")} - expected #{test["valid"]}, got #{JSON::Validator.validate(test_desc["schema"], test["data"], :version => :draft3)}"
			  		end
			  	rescue
			  			puts "#{red("fail")} - exception thrown"
			  	end
	  		end
  		end
  	end
  end

  def colorize(color_code,text)
    "\e[#{color_code}m#{text}\e[0m"
  end

  def red(text)
    colorize(31,text)
  end

  def green(text)
    colorize(32,text)
  end
end