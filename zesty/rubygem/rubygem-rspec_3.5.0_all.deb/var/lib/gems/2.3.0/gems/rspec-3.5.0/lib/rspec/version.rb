module RSpec # :nodoc:
  module Version # :nodoc:
    STRING = '3.5.0'
  end
end
