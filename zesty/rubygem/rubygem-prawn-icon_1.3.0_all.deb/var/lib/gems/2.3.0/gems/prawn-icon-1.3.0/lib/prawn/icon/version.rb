# encoding: utf-8
#
# version.rb: Prawn icon versioning.
#
# Copyright October 2014, Jesse Doyle. All rights reserved.
#
# This is free software. Please see the LICENSE and COPYING files for details.

module Prawn
  class Icon
    VERSION = '1.3.0'.freeze
  end
end
