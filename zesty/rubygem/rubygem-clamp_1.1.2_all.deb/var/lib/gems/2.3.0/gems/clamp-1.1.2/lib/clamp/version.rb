module Clamp
  VERSION = "1.1.2".freeze
end
