module ChildProcess
  VERSION = '0.7.0'
end
