module Git
  class WorkingDirectory < Git::Path
  end
end
