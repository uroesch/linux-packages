module Git

  # The current gem version
  # @return [String] the current gem version.
  VERSION='1.3.0'

end
