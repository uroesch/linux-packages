module Serverspec
  module Commands
    class Base < Specinfra::Command::Base
    end
  end
end

