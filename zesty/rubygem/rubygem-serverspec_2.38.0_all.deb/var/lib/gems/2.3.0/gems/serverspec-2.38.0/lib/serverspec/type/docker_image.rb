module Serverspec::Type
  class DockerImage < DockerBase
  end
end
