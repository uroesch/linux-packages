module Serverspec
  VERSION = "2.38.0"
end
