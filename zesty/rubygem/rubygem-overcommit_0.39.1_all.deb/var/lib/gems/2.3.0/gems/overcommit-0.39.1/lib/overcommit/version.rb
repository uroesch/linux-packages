# frozen_string_literal: true

# Defines the gem version.
module Overcommit
  VERSION = '0.39.1'.freeze
end
