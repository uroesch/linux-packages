class MimeMagic
  # MimeMagic version string
  # @api public
  VERSION = '0.3.2'
end
