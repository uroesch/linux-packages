## 0.0.7.2 (2016-02-01)

- Version bump just for adding Windows binaries for Ruby 2.3.

## 0.0.7.1 (2015-04-18)

- Windows fat binary gems no longer require libstd++ to
  run, which are statically linked.

- Add a fat binary gem for x64-mingw32 (64bit Windows).

- Windows fat binary gems now include binaries for Ruby up to 2.2.

## 0.0.6 (2013-02-16)

- Migrate from Jeweler to Bundler.

## 0.0.5 (2012-05-30)

- Fix a type error for strict compilers.

## 0.0.4 (2011-12-08)

- Release under the current name of `unf_ext`.
