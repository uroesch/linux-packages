module Sprockets
  VERSION = "3.7.1"
end
