require 'yui/compressor'

module Sprockets
  module Autoload
    YUI = ::YUI
  end
end
