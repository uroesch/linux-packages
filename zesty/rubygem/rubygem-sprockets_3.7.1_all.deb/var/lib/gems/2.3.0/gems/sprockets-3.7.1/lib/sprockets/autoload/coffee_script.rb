require 'coffee_script'

module Sprockets
  module Autoload
    CoffeeScript = ::CoffeeScript
  end
end
