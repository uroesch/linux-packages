require 'eco'

module Sprockets
  module Autoload
    Eco = ::Eco
  end
end
