# Deprecated: Require sprockets/sass_processor instead
require 'sprockets/sass_processor'
