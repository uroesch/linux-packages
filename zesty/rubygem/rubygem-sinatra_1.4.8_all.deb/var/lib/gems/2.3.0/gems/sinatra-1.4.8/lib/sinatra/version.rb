module Sinatra
  VERSION = '1.4.8'
end
