module RSpec
  module Expectations
    # @private
    module Version
      STRING = '3.5.0'
    end
  end
end
