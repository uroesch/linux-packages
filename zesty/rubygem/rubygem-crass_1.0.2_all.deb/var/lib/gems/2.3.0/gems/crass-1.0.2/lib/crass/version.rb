# encoding: utf-8

module Crass
  VERSION = '1.0.2'
end
