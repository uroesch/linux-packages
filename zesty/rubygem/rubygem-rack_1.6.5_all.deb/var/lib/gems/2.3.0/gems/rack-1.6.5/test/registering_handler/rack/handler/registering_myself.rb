module Rack
  module Handler
    class RegisteringMyself
    end

    register :registering_myself, RegisteringMyself
  end
end