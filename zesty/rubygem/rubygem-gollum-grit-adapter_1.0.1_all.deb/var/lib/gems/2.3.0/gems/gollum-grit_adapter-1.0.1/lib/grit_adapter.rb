require 'grit_adapter/git_layer_grit.rb'
