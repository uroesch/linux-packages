module Gollum
  module Lib
    module Git
      VERSION = '1.0.1'
    end
  end
end
