module Parallel
  VERSION = Version = '1.11.1'
end
