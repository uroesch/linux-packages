fails:Kernel.__callee__ returns the current method, even when aliased
fails:Kernel.__callee__ returns the original name when aliased method
fails:Kernel.__callee__ returns the caller from blocks too
fails:Kernel.__callee__ returns nil when not called from a method
fails:Kernel.__callee__ returns the caller when sent as a string
fails:Kernel.__callee__ returns the aliased name when aliased method
