fails:Array#rotate returns subclass instance for Array subclasses
fails:Array#rotate! raises a RuntimeError on a frozen array
