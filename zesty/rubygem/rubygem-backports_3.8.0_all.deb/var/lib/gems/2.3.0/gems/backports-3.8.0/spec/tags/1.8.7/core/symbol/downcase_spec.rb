fails:Symbol#downcase leaves lowercase Unicode characters as they were
fails:Symbol#downcase leaves uppercase Unicode characters as they were
