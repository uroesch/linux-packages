fails:Range#size returns nil if first and last are not Numeric
