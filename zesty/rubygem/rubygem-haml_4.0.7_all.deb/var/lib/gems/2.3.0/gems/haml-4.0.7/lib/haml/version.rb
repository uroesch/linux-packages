module Haml
  VERSION = '4.0.7'
end
