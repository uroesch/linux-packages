file "put file in default2.rb" do
  action :nothing
  path "/tmp/created_in_default2"
  content 'Hello'
end

