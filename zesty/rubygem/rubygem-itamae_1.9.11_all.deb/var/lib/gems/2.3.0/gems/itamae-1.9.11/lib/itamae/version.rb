module Itamae
  VERSION = "1.9.11"
end
