require 'spec_helper'

module Itamae
  describe Recipe do
  end
end
