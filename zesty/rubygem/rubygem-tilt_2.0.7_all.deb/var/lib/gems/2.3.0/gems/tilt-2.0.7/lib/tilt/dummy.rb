# Used for detecting autoloading bug in JRuby
class Tilt::Dummy; end

