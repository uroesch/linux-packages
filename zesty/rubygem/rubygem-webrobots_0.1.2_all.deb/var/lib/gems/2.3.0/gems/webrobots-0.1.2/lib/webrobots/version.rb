module Webrobots
  VERSION = "0.1.2"
end
