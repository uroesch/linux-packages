require 'optparse'
require 'asciidoctor/cli/options'
require 'asciidoctor/cli/invoker'
