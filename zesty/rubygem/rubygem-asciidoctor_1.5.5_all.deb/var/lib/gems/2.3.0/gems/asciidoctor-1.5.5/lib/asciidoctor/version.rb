module Asciidoctor
  VERSION = '1.5.5'
end
