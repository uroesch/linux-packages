# nanoc-asciidoctor news

## 1.0.2

* Added support for Nanoc 4.x

## 1.0.1

* Added support for Asciidoctor 1.x

## 1.0.0

Initial release.
