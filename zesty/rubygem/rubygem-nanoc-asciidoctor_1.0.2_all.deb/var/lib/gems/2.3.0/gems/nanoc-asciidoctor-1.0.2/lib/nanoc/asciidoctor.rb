# encoding: utf-8

module Nanoc
  module Asciidoctor
  end
end

require 'nanoc/asciidoctor/version'
require 'nanoc/asciidoctor/filter'
