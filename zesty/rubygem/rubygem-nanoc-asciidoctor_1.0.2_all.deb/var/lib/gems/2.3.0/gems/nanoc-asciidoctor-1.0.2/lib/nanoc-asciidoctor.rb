# encoding: utf-8

require 'nanoc/asciidoctor'
