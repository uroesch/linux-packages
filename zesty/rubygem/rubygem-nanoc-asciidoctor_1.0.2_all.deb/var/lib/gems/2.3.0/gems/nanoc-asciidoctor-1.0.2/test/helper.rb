# encoding: utf-8

require 'coveralls'
Coveralls.wear!

require 'minitest'
require 'minitest/autorun'
require 'nanoc'
require 'nanoc-asciidoctor'
