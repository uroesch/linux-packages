# encoding: utf-8

module Nanoc
  module Asciidoctor

    VERSION = '1.0.2'

  end
end
