class DomainName
  VERSION = '0.5.20170223'
end
