module Prawn
  class Table
    VERSION = '0.2.2'.freeze
  end
end
