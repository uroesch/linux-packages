module Diffy
  VERSION = '3.2.0'
end
