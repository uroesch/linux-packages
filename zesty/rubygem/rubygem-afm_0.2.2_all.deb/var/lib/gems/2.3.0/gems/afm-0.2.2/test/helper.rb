require 'rubygems'
require 'bundler/setup'
require 'minitest/autorun'
require 'afm'
