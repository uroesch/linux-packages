## 0.2.2

* The gem was missing 

## 0.2.1

* Fixed rdoc tasks, replaced Test::Unit with Minitest (Thanks to @yob, @strzibny for changes)
* Removed jeweler dependency

