module Kernel
  def BigDecimal(initial, digits = 0)
    BigDecimal.new(initial, digits)
  end
end
