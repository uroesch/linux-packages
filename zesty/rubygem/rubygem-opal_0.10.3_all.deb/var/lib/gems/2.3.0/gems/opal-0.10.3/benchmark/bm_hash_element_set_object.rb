h = {}

100_000.times do |i|
  h[Object.new] = nil
end
