10_000.times do
  h = {'a' => 'b', Object.new => 'd', 'e' => 'f', Object.new => 'h', 'i' => 'j', Object.new => 'l', 'm' => 'n', Object.new => 'p'}
end
