require 'nodejs/yaml' if defined? NodeJS
