h = {}

10_000.times do |i|
  h[i.to_s] = nil
end

100.times do |i|
  h.clone
end
