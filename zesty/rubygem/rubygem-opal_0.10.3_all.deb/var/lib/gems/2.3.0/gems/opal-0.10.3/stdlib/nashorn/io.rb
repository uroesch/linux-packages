$stdout.write_proc = `function(s){print(s)}`
$stderr.write_proc = `function(s){print(s)}`
