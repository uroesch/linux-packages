module NodeJS
end

require 'nodejs/kernel'
require 'nodejs/file'
require 'nodejs/dir'
require 'nodejs/io'
