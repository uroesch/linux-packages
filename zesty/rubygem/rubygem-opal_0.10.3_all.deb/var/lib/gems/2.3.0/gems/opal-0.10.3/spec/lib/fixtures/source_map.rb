puts 'smap!'
