module SourceMap
  VERSION = "0.0.2"
end
