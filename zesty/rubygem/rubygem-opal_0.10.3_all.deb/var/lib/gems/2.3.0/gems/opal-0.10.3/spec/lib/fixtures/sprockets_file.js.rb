require 'opal'
require 'native'
puts 'sprockets!'
