require 'opal'
puts 'hi from opal!'
