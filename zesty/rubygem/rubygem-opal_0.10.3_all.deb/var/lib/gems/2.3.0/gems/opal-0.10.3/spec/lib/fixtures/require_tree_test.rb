require_tree '../fixtures/required_tree_test'

puts 5
