warn "File is already part of corelib now, you don't need to require it anymore."
