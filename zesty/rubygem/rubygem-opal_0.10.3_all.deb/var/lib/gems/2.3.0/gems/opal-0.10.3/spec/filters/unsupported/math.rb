opal_filter "Math" do
  fails "Math#atanh is a private instance method"
end
