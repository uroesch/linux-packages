warn "DEPRECATION: encoding is now part of the core library, requiring it is deprecated"
