require 'foo'

puts 'hello'

require 'bar'

puts 'goodbye'
