10_000.times do
  h = {Object.new => 'b', Object.new => 'd', Object.new => 'f', Object.new => 'h', Object.new => 'j', Object.new => 'l', Object.new => 'n', Object.new => 'p'}
end
