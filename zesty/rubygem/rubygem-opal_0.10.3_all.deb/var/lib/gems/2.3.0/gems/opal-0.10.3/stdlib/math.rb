warn "DEPRECATION: math is now part of the core library, requiring it is deprecated"
