a = []

1000.times do |i|
  a << [i]
end

1000.times do
  a.join
end
