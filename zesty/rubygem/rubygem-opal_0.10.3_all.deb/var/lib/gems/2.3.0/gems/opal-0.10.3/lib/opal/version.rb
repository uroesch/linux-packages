module Opal
  # WHEN RELEASING:
  # Remember to update RUBY_ENGINE_VERSION in opal/corelib/constants.rb too!
  VERSION = '0.10.3'
end
