h = {}

100_000.times do |i|
  h[i.to_s] = nil
end
