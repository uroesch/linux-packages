opal_filter "Proc" do
  fails "Proc#hash returns an Integer"
end
