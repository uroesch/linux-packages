module Nashorn
end

require 'nashorn/io'
require 'nashorn/file'
