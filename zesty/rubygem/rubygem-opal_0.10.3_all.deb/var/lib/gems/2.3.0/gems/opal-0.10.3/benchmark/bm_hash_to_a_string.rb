h = {}

10_000.times do |i|
  h[i.to_s] = nil
end

5_000.times do
  h.to_a
end
