def self.to_s
  'main'
end

def self.include(mod)
  Object.include mod
end
