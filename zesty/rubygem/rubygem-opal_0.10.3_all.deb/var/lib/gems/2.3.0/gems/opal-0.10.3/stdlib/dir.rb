warn "Dir is already part of corelib now, you don't need to require it anymore."
