module Zip
  VERSION = '1.2.1'
end
