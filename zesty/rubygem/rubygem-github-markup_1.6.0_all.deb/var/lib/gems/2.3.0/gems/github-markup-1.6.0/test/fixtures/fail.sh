#!/usr/bin/env bash

echo "failure message">&2 && false
