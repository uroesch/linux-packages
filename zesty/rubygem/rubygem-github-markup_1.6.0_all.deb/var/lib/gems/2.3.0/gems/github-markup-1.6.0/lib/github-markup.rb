module GitHub
  module Markup
    VERSION = '1.6.0'
    Version = VERSION
  end
end
