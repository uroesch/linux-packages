fails:Hash#keep_if raises an RuntimeError if called on a frozen instance
fails:Hash#keep_if raises a RuntimeError if called on a frozen instance
