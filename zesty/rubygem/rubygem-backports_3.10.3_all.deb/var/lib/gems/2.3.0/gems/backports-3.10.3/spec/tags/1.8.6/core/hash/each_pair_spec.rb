fails:Hash#each_pair yields a [[key, value]] Array for each pair to a block expecting |*args|
