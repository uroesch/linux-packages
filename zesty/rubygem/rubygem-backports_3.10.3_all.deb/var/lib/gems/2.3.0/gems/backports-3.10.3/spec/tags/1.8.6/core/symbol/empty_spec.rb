fails:Symbol#empty? returns true if self is empty
