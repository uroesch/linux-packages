fails:Symbol#upcase leaves lowercase Unicode characters as they were
