fails:Hash#rassoc only returns the first matching key-value pair
