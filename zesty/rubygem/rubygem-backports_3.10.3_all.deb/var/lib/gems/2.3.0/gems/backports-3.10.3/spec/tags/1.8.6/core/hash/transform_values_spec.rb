fails:Hash#transform_values when no block is given returns a sized Enumerator
fails:Hash#transform_values! when no block is given returns a sized Enumerator
