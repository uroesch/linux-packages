fails:Method#curry with optional arity argument raises ArgumentError when the method requires less arguments than the given arity
