fails:IO.write uses encoding from given options, if provided
fails:IO.write uses an :open_args option
fails:IO.write uses the given encoding and returns the number of bytes written
