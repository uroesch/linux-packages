Backports::StdLib.extend_relative
