fails:Hash#eql? computes equality for recursive hashes
fails:Hash#eql? computes equality for complex recursive hashes
fails:Hash#eql? computes equality for recursive hashes & arrays
