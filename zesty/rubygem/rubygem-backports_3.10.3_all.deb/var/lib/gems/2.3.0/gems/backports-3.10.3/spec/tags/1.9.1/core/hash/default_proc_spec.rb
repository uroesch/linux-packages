fails:Hash#default_proc= raises a TypeError if passed a lambda with an arity other than 2
