fails:String#+@ returns mutable copy despite freeze-magic-comment in file
