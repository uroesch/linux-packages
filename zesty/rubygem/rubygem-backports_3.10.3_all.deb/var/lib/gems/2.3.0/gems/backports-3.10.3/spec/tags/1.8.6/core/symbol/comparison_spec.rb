fails:Symbol#<=> with Symbol compares individual characters based on their ascii value
