module Ascii85
  VERSION = "1.0.2"
end
