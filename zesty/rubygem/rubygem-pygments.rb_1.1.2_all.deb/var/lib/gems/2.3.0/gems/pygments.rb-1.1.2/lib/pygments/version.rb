# coding: utf-8
# frozen_string_literal: true
module Pygments
  VERSION = '1.1.2'
end
