Autotest.add_discovery { "rspec2" }
