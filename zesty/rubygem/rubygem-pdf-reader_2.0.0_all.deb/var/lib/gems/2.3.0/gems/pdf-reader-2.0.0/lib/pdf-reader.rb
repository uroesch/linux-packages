# coding: utf-8

require "pdf/reader"
