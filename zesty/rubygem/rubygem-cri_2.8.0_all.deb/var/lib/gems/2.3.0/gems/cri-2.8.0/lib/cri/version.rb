module Cri
  # The current Cri version.
  VERSION = '2.8.0'.freeze
end
