require 'helper'

module Cri
  class BaseTestCase < Cri::TestCase
    def test_stub; end
  end
end
