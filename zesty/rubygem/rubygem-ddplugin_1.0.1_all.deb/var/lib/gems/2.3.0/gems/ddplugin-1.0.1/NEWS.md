# ddplugin release notes

## 1.0.1 (2017-02-28)

Fixes:

* Made `.all` not return duplicates (#3)

## 1.0 (2016-11-27)

Initial release.
