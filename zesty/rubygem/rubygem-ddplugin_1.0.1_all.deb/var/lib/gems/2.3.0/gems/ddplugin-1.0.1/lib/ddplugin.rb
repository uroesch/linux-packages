require 'ddplugin/version'
require 'ddplugin/plugin'
require 'ddplugin/registry'
