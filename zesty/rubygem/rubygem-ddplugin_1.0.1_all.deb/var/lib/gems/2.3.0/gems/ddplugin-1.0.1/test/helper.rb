require 'coveralls'
Coveralls.wear!

require 'minitest'
require 'minitest/autorun'

require 'ddplugin'
