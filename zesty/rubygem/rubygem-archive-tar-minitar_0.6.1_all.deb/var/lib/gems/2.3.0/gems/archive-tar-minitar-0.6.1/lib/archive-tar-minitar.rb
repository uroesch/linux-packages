# coding: utf-8

require 'archive/tar/minitar'
