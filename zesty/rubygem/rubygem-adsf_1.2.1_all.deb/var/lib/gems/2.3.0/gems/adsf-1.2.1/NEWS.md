adsf News
=========

1.2.1
-----

* Fixed compatibility with Ruby 2.3.0 (#3) [Vipul Amler]

1.2.0
-----

* Add `--local-only` and `--listen-address` options (#1) [Ed Brannin]

1.1.1
-----

* Made SIGINT/SIGTERM cause proper exit

1.1.0
-----

* Added support for custom index filenames [Mark Meves]

1.0.1
-----

* Added runtime dependency on Rack

1.0
---

* Initial release
