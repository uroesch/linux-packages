module Adsf

  VERSION = '1.2.1'

end

require 'adsf/rack'
