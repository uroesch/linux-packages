module Adsf

  module Rack
  end

end

require 'adsf/rack/index_file_finder'
