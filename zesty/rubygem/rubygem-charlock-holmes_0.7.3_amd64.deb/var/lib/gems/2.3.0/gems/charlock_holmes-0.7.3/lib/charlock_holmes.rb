require 'charlock_holmes/charlock_holmes'
require 'charlock_holmes/encoding_detector'
require 'charlock_holmes/version' unless defined? CharlockHolmes::VERSION

# require this if you want the String monkey patches
# require 'charlock_holmes/string'
