module Hamster
  # Current released gem version. Note that master will often have the same
  # value as a release gem but with different code.
  VERSION = "3.0.0"
end
