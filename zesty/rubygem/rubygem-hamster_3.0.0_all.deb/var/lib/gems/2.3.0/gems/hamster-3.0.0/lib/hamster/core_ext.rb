require "hamster/core_ext/enumerable"
require "hamster/core_ext/io"
