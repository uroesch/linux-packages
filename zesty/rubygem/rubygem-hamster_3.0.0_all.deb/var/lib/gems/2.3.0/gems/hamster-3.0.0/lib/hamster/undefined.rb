module Hamster
  # @private
  module Undefined
  end
end
