# v4.2.1

* Performances improvements
* Dependency updates

# v4.2.0

* Changes since v4.1.0:
  ** Various performance improvements
  ** Dependency updates
  ** Bugfixes
  ** New Macro for listing contents of (sub)directories: `Navigation()`
  ** Table of Contents now supports setting max heading level 

# v4.0.2 /2015-0119

* Bugfixes

# v4.0.1 /2014-12-04

* Security fix for [remote code execution issue](https://github.com/gollum/gollum/issues/913). Please update!

# v0.0.1 / 2013-03-19

* First release, extrated from https://github.com/gollum/gollum
