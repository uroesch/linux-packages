module Gollum
  module Lib
    VERSION = '4.2.3'
  end
end