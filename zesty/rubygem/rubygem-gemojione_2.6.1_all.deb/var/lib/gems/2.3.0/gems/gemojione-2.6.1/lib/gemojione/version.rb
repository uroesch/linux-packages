module Gemojione
  VERSION = "2.6.1"
end
