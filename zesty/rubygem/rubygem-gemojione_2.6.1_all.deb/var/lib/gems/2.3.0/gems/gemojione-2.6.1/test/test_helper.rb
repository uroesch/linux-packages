require 'rubygems'
require 'bundler/setup'

require 'gemojione'

require 'minitest/autorun'
require 'minitest/pride'
