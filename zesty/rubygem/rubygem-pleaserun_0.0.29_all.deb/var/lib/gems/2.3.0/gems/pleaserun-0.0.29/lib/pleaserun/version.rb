module PleaseRun
  VERSION = "0.0.29"
end
