fails:Kernel#public_method returns a method object if we repond_to_missing? method
fails:Kernel#public_method changes the method called for super on a target aliased method
