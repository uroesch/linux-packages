module Dotenv
  VERSION = "2.2.1".freeze
end
