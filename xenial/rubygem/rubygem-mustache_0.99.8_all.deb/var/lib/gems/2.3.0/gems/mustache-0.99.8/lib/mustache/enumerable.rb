class Mustache
  Enumerable = Module.new
end
