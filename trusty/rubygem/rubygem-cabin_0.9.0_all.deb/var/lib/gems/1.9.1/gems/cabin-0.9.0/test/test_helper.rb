require "rubygems"
require "support/minitest-patch"
require "minitest/autorun"
require "cabin"
require "stringio"
require "simplecov"

SimpleCov.start
