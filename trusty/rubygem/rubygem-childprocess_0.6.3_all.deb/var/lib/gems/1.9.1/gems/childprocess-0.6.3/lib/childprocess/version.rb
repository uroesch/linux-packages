module ChildProcess
  VERSION = '0.6.3'
end
