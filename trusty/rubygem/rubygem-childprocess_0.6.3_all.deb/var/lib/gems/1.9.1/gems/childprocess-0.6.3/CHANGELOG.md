### Version 0.6.3 / 2017-03-24

See beta release notes.


### Version 0.6.3.beta.1 / 2017-03-10

* Bug fix: Fixed child process creation problems on Windows 7 when a child was declared as a leader.


### Version 0.6.2 / 2017-02-25

* Bug fix: Fixed a potentially broken edge case that could occur on older 32-bit OSX systems.


### Version 0.6.1 / 2017-01-22

* Bug fix: Fixed a dependency that was accidentally declared as a runtime 
  dependency instead of a development dependency.


### Version 0.6.0 / 2017-01-22

* Support for Ruby 2.4 added


### Version 0.5.9 / 2016-01-06

* The Great Before Times...
