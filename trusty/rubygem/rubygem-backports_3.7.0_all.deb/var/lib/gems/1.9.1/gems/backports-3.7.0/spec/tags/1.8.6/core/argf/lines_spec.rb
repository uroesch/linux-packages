fails:ARGF.lines is a public method
fails:ARGF.lines requires multiple arguments
fails:ARGF.lines reads each line of files
fails:ARGF.lines returns self when passed a block
fails:ARGF.lines returns an Enumerator when passed no block
fails:ARGF.lines with a separator yields each separated section of all streams
