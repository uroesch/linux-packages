fails:Module#class_exec defines method in the receiver's scope
fails:Module#class_exec raises an LocalJumpError when no block is given
