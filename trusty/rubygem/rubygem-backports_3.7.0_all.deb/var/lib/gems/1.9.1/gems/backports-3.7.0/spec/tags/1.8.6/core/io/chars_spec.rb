fails:IO#chars yields each character
