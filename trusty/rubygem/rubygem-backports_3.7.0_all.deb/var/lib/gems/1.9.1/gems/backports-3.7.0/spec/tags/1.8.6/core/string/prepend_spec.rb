fails:String#prepend raises a RuntimeError when self if frozen
