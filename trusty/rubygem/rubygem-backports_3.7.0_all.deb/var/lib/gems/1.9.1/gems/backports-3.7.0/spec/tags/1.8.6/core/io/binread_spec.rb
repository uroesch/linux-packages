fails:IO.binread reads the contents of a file
fails:IO.binread reads the contents of a file up to a certain size when specified
fails:IO.binread reads the contents of a file from an offset of a specific size when specified
fails:IO.binread returns a String in ASCII-8BIT encoding
fails:IO.binread returns a String in ASCII-8BIT encoding regardless of Encoding.default_internal
fails:IO.binread raises an ArgumentError when not passed a valid length
fails:IO.binread raises an Errno::EINVAL when not passed a valid offset
