fails:Symbol#[] with a Regex slice without a capture index sets $~ to the MatchData if there is a match
fails:Symbol#[] with a Regex slice with a capture index sets $~ to the MatchData if there is a match
fails:Symbol#[] with a Regex slice without a capture index returns an untrusted string if the regexp is untrusted
fails:Symbol#[] with a Regex slice with a capture index returns an untrusted string if the regexp is untrusted
