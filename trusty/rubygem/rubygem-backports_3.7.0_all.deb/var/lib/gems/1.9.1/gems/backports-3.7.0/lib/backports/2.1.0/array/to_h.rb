# No need to specialize it, just use Enumerable's implementation:
require 'backports/2.1.0/enumerable/to_h'
