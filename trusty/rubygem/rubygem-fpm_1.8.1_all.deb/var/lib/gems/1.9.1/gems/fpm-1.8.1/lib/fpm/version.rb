module FPM
  VERSION = "1.8.1"
end
