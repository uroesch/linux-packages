fails:IO#lines ignores a given block
