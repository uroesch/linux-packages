fails:Array#bsearch_index when not passed a block returns an Enumerator with unknown size
