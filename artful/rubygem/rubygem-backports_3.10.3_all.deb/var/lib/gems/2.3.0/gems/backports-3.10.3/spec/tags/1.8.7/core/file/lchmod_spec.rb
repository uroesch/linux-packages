fails:File.lchmod returns false from #respond_to?
fails:File.lchmod raises a NotImplementedError when called
