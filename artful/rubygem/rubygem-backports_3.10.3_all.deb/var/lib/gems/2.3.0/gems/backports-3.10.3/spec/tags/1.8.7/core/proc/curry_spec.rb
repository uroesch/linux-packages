fails:Proc#curry produces Procs that raise ArgumentError for #binding
fails:Proc#curry produces Procs that return [[:rest]] for #parameters
fails:Proc#curry produces Procs that return nil for #source_location
