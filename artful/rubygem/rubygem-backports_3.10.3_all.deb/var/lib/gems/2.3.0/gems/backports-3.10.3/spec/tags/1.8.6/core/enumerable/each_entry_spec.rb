fails:Enumerable#each_entry passes through the values yielded by #each_with_index
