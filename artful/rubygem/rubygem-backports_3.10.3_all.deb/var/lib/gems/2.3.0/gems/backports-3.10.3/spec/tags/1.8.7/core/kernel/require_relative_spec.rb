fails:Kernel#require_relative with a relative path stores the missing path in a LoadError object
fails:Kernel#require_relative with a relative path when file is a symlink loads a path relative to current file
fails:Kernel#require_relative with an absolute path stores the missing path in a LoadError object
