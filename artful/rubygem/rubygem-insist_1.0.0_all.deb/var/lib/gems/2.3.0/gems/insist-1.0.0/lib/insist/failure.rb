# A failure. This is raised if an `insist` check fails.
class Insist::Failure < StandardError
  # Nothing here.
end
