module FFI
  VERSION = '1.9.18'
end

